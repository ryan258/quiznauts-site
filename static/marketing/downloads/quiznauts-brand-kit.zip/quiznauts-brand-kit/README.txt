Quiznauts brand kit / production library v1.4. Clean SVG artwork, mascot PNG exports and lossless WebP copies.
Preserve Mr. Big's round paws and feet, compact proportions and asymmetric temple patch. Never mirror his head. Keep essential text high contrast.
The actual toy reference photo, private source records and question banks are not included. Distribution terms remain an owner decision.
