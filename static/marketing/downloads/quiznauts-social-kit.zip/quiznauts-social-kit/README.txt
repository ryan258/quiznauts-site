Quiznauts social kit. SVG masters, full-size PNG exports and lossless WebP copies. See manifest.json for dimensions, intended properties and safe-area guides.
Question/answer cards must stay tied to their recorded factual source. Template art does not establish that a matching video is published.
Crop guides are production guides; inspect the actual upload on the chosen platform before publishing. No blanket reuse license is asserted here.
